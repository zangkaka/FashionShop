package rang.com.fashionshop;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.daimajia.slider.library.SliderTypes.BaseSliderView;
import com.daimajia.slider.library.SliderTypes.TextSliderView;
import java.util.ArrayList;
import java.util.HashMap;

public class  MainActivity extends AppCompatActivity implements BaseSliderView.OnSliderClickListener {
    SliderLayout mDemoSlider;

    private RecyclerView rv,rv2,rv3;
    private ArrayList<BeanlistGrooming> Bean;
    private GroomingRecyclerViewAdapter baseAdapter;
    private ArrayList<BeanlistTrending> Bean1;
    private TrendingRecyclerViewAdapter baseAdapter1;
    private ArrayList<BeanlistBrands> Bean2;
    private BrandsRecyclerViewAdapter baseAdapter2;
    private Context context;
    Typeface fonts1,fonts2,fonts3,fonts4;
    TextView eshop,shirt1,jeans1,shoes1,slippers1,goggles1,groomingproducts,trendingproducts,topbrands;
    EditText searchtext;
    LinearLayout home0,offer0,fav0,bag0,noti0;
    ImageView home,offer,fav,bag,noti;

//    *****Grooming string*******
    private int[] IMAGEG = {R.drawable.shoppy_logo, R.drawable.shoppy_logo, R.drawable.shoppy_logo, R.drawable.shoppy_logo};
    private String[] TITLEG = {"Canvera Black Heel", "Canvera Black Heel", "Canvera Black Heel", "Canvera Black Heel"};
    private String[] DESCRIPTIONG = {"1200 Rs", "1200 Rs", "1200 Rs", "1200 Rs"};
    private String[] DATEG = {"200 Rs", "200 Rs", "200 Rs", "200 Rs"};
    private String[] DISCOUNTG = {"15%", "10%", "25%", "50%"};
    private String[] RATINGTEXTG = {"(1234)", "(2322)", "(4322)", "(1223)"};

    //    *****Trending string*******
    private int[] IMAGET = {R.drawable.shoppy_logo, R.drawable.shoppy_logo, R.drawable.shoppy_logo, R.drawable.shoppy_logo};
    private String[] TITLET = {"Canvera Black Heel", "Canvera Black Heel", "Canvera Black Heel", "Canvera Black Heel"};
    private String[] DESCRIPTIONT = {"1200 Rs", "1200 Rs", "1200 Rs", "1200 Rs"};
    private String[] DATET = {"200 Rs", "200 Rs", "200 Rs", "200 Rs"};
    private String[] DISCOUNTT = {"15%", "10%", "25%", "50%"};
    private String[] RATINGTEXTT = {"(1234)", "(2322)", "(4322)", "(1223)"};

    //    *****Brands string*******
    private int[] IMAGEB = {R.drawable.shoppy_logo, R.drawable.shoppy_logo, R.drawable.shoppy_logo};
    private String[] TEXT1 = {"Nike", "Microwaves", "Nike"};
    private String[] TEXT2 = {"Adidas", "Chimneys", "Adidas"};
    private String[] TEXT3 = {"UCB", "Gas Stoves ", "UCB"};
    private String[] TEXT4 = {"Levis", "Water Purifiers", "Levis"};
    private String[] TEXT5 = {"Kuotons", "Electric Cookers", "Kuotons"};
    private String[] TEXT6 = {"See More", "Roti Makers", "See More"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


//


    eshop = (TextView) findViewById(R.id.eshop);
        shirt1 = (TextView) findViewById(R.id.shirt1);
        jeans1 = (TextView) findViewById(R.id.jeans1);
        shoes1 = (TextView) findViewById(R.id.shoes1);
        slippers1 = (TextView) findViewById(R.id.slippers1);
        goggles1 = (TextView) findViewById(R.id.goggles1);
        groomingproducts = (TextView) findViewById(R.id.groomingproducts);
        trendingproducts = (TextView) findViewById(R.id.trendingproducts);
        topbrands = (TextView) findViewById(R.id.topbrands);
        searchtext = (EditText) findViewById(R.id.searchtext);

//     *******BOT BAR COLOR *********
        home = (ImageView) findViewById(R.id.home);
        home0 =(LinearLayout)findViewById(R.id.home0);
        offer = (ImageView) findViewById(R.id.offer);
        offer0 =(LinearLayout)findViewById(R.id.offer0);
        fav = (ImageView) findViewById(R.id.fav);
        fav0 =(LinearLayout)findViewById(R.id.fav0);
        bag = (ImageView) findViewById(R.id.bag);
        bag0 =(LinearLayout)findViewById(R.id.bag0);
        noti = (ImageView) findViewById(R.id.noti);
        noti0 =(LinearLayout)findViewById(R.id.noti0);

//        home.setColorFilter(getResources().getColor(R.color.red), android.graphics.PorterDuff.Mode.MULTIPLY);
        home.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        offer.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        fav.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        bag.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        noti.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);


        home0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickb("1");

            }
        });
        offer0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickb("2");

            }
        });
        fav0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickb("3");

            }
        });
        bag0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickb("4");

            }
        });
        noti0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                clickb("5");

            }
        });


        fonts1 =  Typeface.createFromAsset(getAssets(),
                "fonts/OpenSans-Regular.ttf");
        fonts2 =  Typeface.createFromAsset(getAssets(),
                "fonts/OpenSans-Semibold.ttf");

        fonts3 =  Typeface.createFromAsset(getAssets(),
                "fonts/Roboto-Medium.ttf");

        fonts4 =  Typeface.createFromAsset(getAssets(),
                "fonts/Roboto-Regular.ttf");

        eshop.setTypeface(fonts1);
        searchtext.setTypeface(fonts1);
        shirt1.setTypeface(fonts4);
        jeans1.setTypeface(fonts4);
        shoes1.setTypeface(fonts4);
        slippers1.setTypeface(fonts4);
        goggles1.setTypeface(fonts4);
        groomingproducts.setTypeface(fonts2);
        trendingproducts.setTypeface(fonts2);
        topbrands.setTypeface(fonts2);

//*********RECYCLERVIEWS*********

        rv = (RecyclerView)findViewById(R.id.rv);
        rv2 = (RecyclerView)findViewById(R.id.rv2);
        rv3 = (RecyclerView)findViewById(R.id.rv3);

        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv.setLayoutManager(mLayoutManager);

        RecyclerView.LayoutManager mLayoutManager1 = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv2.setLayoutManager(mLayoutManager1);


        RecyclerView.LayoutManager mLayoutManager2 = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        rv3.setLayoutManager(mLayoutManager2);




        Bean = new ArrayList<BeanlistGrooming>();

        for (int i= 0; i< TITLEG.length; i++){

            BeanlistGrooming bean = new BeanlistGrooming(IMAGEG[i], TITLEG[i], DESCRIPTIONG[i], DATEG[i],DISCOUNTG[i], RATINGTEXTG[i]);
            Bean.add(bean);

        }


        baseAdapter = new GroomingRecyclerViewAdapter(this,MainActivity.this, Bean) {
        };




        Bean1 = new ArrayList<BeanlistTrending>();

        for (int i= 0; i< TITLET.length; i++){

            BeanlistTrending bean1 = new BeanlistTrending(IMAGET[i], TITLET[i], DESCRIPTIONT[i], DATET[i],DISCOUNTT[i], RATINGTEXTT[i]);
            Bean1.add(bean1);

        }


        baseAdapter1 = new TrendingRecyclerViewAdapter(this,MainActivity.this, Bean1) {
        };



        Bean2 = new ArrayList<BeanlistBrands>();

        for (int i= 0; i< IMAGEB.length; i++){

            BeanlistBrands bean2 = new BeanlistBrands(IMAGEB[i], TEXT1[i], TEXT2[i], TEXT3[i],TEXT4[i], TEXT5[i], TEXT6[i]);
            Bean2.add(bean2);

        }


        baseAdapter2 = new BrandsRecyclerViewAdapter(MainActivity.this, Bean2) {
        };

        rv.setAdapter(baseAdapter);
        rv2.setAdapter(baseAdapter1);
        rv3.setAdapter(baseAdapter2);





        //         ********Slider*********

        mDemoSlider = (SliderLayout)findViewById(R.id.slider);

        HashMap<String,Integer> file_maps = new HashMap<String, Integer>();
        file_maps.put("1", R.drawable.shoppy_logo);
        file_maps.put("2",R.drawable.shoppy_logo);
        file_maps.put("3",R.drawable.shoppy_logo);


        for(String name : file_maps.keySet()){
            TextSliderView textSliderView = new TextSliderView(this);
            // initialize a SliderLayout
            textSliderView
                    //  .description(name)
                    .image(file_maps.get(name))
                    .setScaleType(BaseSliderView.ScaleType.CenterInside)
                    .setOnSliderClickListener(this);


            textSliderView.bundle(new Bundle());
            textSliderView.getBundle().putString("extra", name);

            mDemoSlider.addSlider(textSliderView);
        }
        mDemoSlider.setPresetTransformer(SliderLayout.Transformer.Default);
        mDemoSlider.setPresetIndicator(SliderLayout.PresetIndicators.Center_Bottom);
        mDemoSlider.setCustomAnimation(new ChildAnimationExample());
        mDemoSlider.setDuration(4000);
        mDemoSlider.addOnPageChangeListener(this);

    }

    @Override
    public void onSliderClick(BaseSliderView slider) {

    }

    private void clickb(String s) {

        home.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        offer.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        fav.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        bag.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);
        noti.setColorFilter(getResources().getColor(R.color.boticon), android.graphics.PorterDuff.Mode.MULTIPLY);



        if(s.equalsIgnoreCase("1")) {

            home.setColorFilter(getResources().getColor(R.color.red), android.graphics.PorterDuff.Mode.MULTIPLY);

        }


        else if(s.equalsIgnoreCase("2")) {

            offer.setColorFilter(getResources().getColor(R.color.red), android.graphics.PorterDuff.Mode.MULTIPLY);

        }
        else if(s.equalsIgnoreCase("3")) {

            fav.setColorFilter(getResources().getColor(R.color.red), android.graphics.PorterDuff.Mode.MULTIPLY);

        }
        else if(s.equalsIgnoreCase("4")) {

            bag.setColorFilter(getResources().getColor(R.color.red), android.graphics.PorterDuff.Mode.MULTIPLY);

        }
        else if(s.equalsIgnoreCase("5")) {

            noti.setColorFilter(getResources().getColor(R.color.red), android.graphics.PorterDuff.Mode.MULTIPLY);

        }

    }
}
